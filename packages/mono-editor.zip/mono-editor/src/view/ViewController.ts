import type { TextModel } from '../core/TextModel';
import type { SelectionState } from '../core/Selection';
import type {
  CanvasRenderer,
  FreeHandleVisual,
  RenderMetrics,
} from '../render/CanvasRenderer';
import type { MonoEditorTheme } from '../api/types';
import type { TokenizationSupport } from '../language/TokenizationSupport';
import {
  DEFAULT_STICKY_SCROLL,
  IndentScopeFinder,
  layoutStickyForScroll,
  type MonoStickyScrollOptions,
  type StickyRenderLine,
} from './StickyScroll';

export class ViewController {
  scrollTop = 0;
  scrollLeft = 0;
  cssWidth = 0;
  cssHeight = 0;
  freeHandle: FreeHandleVisual | null = null;

  private model: TextModel;
  private selection: SelectionState;
  private renderer: CanvasRenderer;
  private getMetrics: () => RenderMetrics;
  private getTheme: () => MonoEditorTheme;
  private showLineNumbers: () => boolean;
  private overscan: number;
  private tokenization: TokenizationSupport | null;
  private stickyOpts: Required<MonoStickyScrollOptions>;
  private scopeFinder: IndentScopeFinder;
  /** Last laid-out sticky rows (for hit-test / click-to-navigate). */
  lastSticky: StickyRenderLine[] = [];
  lastStickyHeight = 0;
  private paintRaf = 0;

  constructor(
    model: TextModel,
    selection: SelectionState,
    renderer: CanvasRenderer,
    getMetrics: () => RenderMetrics,
    getTheme: () => MonoEditorTheme,
    showLineNumbers: () => boolean,
    overscan: number,
    tokenization: TokenizationSupport | null = null,
    stickyScroll?: MonoStickyScrollOptions,
  ) {
    this.stickyOpts = { ...DEFAULT_STICKY_SCROLL, ...stickyScroll };
    this.scopeFinder = new IndentScopeFinder(model);
    this.model = model;
    this.selection = selection;
    this.renderer = renderer;
    this.getMetrics = getMetrics;
    this.getTheme = getTheme;
    this.showLineNumbers = showLineNumbers;
    this.overscan = overscan;
    this.tokenization = tokenization;
  }

  /** Effective gutter width (0 when line numbers are hidden). */
  get contentLeft(): number {
    return this.showLineNumbers() ? this.getMetrics().gutterWidth : 0;
  }

  setSize(width: number, height: number): void {
    this.cssWidth = Math.max(0, width);
    this.cssHeight = Math.max(0, height);
    this.renderer.resize(this.cssWidth, this.cssHeight);
    this.clampScroll();
    this.paint();
  }

  scrollBy(dx: number, dy: number): void {
    this.scrollLeft = Math.max(0, this.scrollLeft + dx);
    this.scrollTop = Math.max(0, this.scrollTop + dy);
    this.clampScroll();
    this.schedulePaint();
  }

  clampScrollPublic(): void {
    this.clampScroll();
  }

  setStickyScroll(opts: MonoStickyScrollOptions): void {
    this.stickyOpts = { ...DEFAULT_STICKY_SCROLL, ...opts };
    this.scopeFinder.invalidate();
    this.schedulePaint();
  }

  invalidateScopes(): void {
    this.scopeFinder.invalidate();
  }

  getStickyScrollOptions(): Required<MonoStickyScrollOptions> {
    return this.stickyOpts;
  }

  ensureCaretVisible(): void {
    const m = this.getMetrics();
    const line = this.selection.active.lineNumber;
    const topY = m.paddingTop + (line - 1) * m.lineHeight;
    if (topY < this.scrollTop + m.paddingTop) {
      this.scrollTop = Math.max(0, topY - m.paddingTop);
    }
    if (topY + m.lineHeight > this.scrollTop + this.cssHeight) {
      this.scrollTop = topY + m.lineHeight - this.cssHeight;
    }
    this.clampScroll();
  }

  /** CSS position of caret relative to root (for textarea placement). */
  caretScreenPos(): { x: number; y: number; h: number } {
    const m = this.getMetrics();
    const line = this.selection.active.lineNumber;
    const col = this.selection.active.column;
    const content = this.model.getLineContent(line);
    const prefix = content.slice(0, Math.max(0, col - 1));
    const textX =
      this.contentLeft +
      m.paddingLeft +
      prefix.length * m.charWidth -
      this.scrollLeft;
    const y = m.paddingTop + (line - 1) * m.lineHeight - this.scrollTop;
    return { x: textX, y, h: m.lineHeight };
  }

  /** Coalesces rapid pointermove/wheel updates into 1 paint per display frame. */
  schedulePaint(): void {
    if (this.paintRaf) return;
    this.paintRaf = requestAnimationFrame(() => {
      this.paintRaf = 0;
      this.paint();
    });
  }

  /** Immediate synchronous paint (used by resize, tap, and rAF loops). */
  paint(): void {
    if (this.paintRaf) {
      cancelAnimationFrame(this.paintRaf);
      this.paintRaf = 0;
    }
    if (this.cssWidth <= 0 || this.cssHeight <= 0) return;

    // Snap scroll to physical pixel grid for rendering (keeps float physics smooth, kills text shimmer)
    const dpr = Math.max(1, window.devicePixelRatio || 1);
    const renderTop = Math.round(this.scrollTop * dpr) / dpr;
    const renderLeft = Math.round(this.scrollLeft * dpr) / dpr;

    const metrics = this.getMetrics();
    let stickyLines: StickyRenderLine[] = [];
    if (this.stickyOpts.enabled) {
      this.scopeFinder.sync(this.model);
      const layout = layoutStickyForScroll(
        this.scopeFinder,
        renderTop,
        metrics,
        this.stickyOpts.maxLineCount,
        this.stickyOpts.scrollWithEditor,
      );
      stickyLines = layout.lines;
      this.lastSticky = stickyLines;
      this.lastStickyHeight = layout.height;
    } else {
      this.lastSticky = [];
      this.lastStickyHeight = 0;
    }

    this.renderer.paint({
      model: this.model,
      selection: this.selection,
      scrollTop: renderTop,
      scrollLeft: renderLeft,
      cssWidth: this.cssWidth,
      cssHeight: this.cssHeight,
      metrics,
      theme: this.getTheme(),
      showLineNumbers: this.showLineNumbers(),
      overscan: this.overscan,
      getLineTokens: this.tokenization
        ? (ln) => this.tokenization!.getLineTokens(this.model, ln)
        : undefined,
      freeHandle: this.freeHandle,
      stickyLines,
    });
  }

  /**
   * Sticky overlay hit-test in root-local CSS coords.
   * Returns sticky index + lineNumber or null.
   */
  hitTestSticky(localX: number, localY: number): { index: number; lineNumber: number } | null {
    if (!this.lastSticky.length || localY < 0 || localY > this.lastStickyHeight + 2) return null;
    // Top-most sticky under point wins (outer first in paint order)
    for (let i = 0; i < this.lastSticky.length; i++) {
      const s = this.lastSticky[i]!;
      if (localY >= s.y && localY < s.y + this.getMetrics().lineHeight) {
        return { index: i, lineNumber: s.lineNumber };
      }
    }
    // Fallback: by slot index
    const m = this.getMetrics();
    const idx = Math.floor(localY / m.lineHeight);
    if (idx >= 0 && idx < this.lastSticky.length) {
      return { index: idx, lineNumber: this.lastSticky[idx]!.lineNumber };
    }
    return null;
  }

  /**
   * VS Code / Acode: scroll so `lineNumber` sits exactly in sticky slot `index`
   * (the sticky header appears to stay put) and place caret on that line.
   */
  /**
   * Scroll so header stays in sticky slot `index`, caret at exact column from localX
   * (click on `function te|st()` → cursor between e and s).
   */
  revealStickyLine(lineNumber: number, index: number, localX?: number): void {
    const m = this.getMetrics();
    const line = Math.max(1, Math.min(this.model.getLineCount(), lineNumber));
    const docY = m.paddingTop + (line - 1) * m.lineHeight;
    this.scrollTop = Math.max(0, docY - index * m.lineHeight);
    this.clampScroll();

    let col = 1;
    if (localX != null) {
      const textX = localX - this.contentLeft - m.paddingLeft + this.scrollLeft;
      const content = this.model.getLineContent(line);
      col = Math.floor(textX / Math.max(1, m.charWidth)) + 1;
      col = Math.max(1, Math.min(content.length + 1, col));
    }
    this.selection.setCaret(line, col);
    this.paint();
  }

  dispose(): void {
    if (this.paintRaf) {
      cancelAnimationFrame(this.paintRaf);
      this.paintRaf = 0;
    }
  }

  private clampScroll(): void {
    const m = this.getMetrics();
    const contentH = this.model.getLineCount() * m.lineHeight + m.paddingTop;
    const maxTop = Math.max(0, contentH - this.cssHeight);
    this.scrollTop = Math.max(0, Math.min(this.scrollTop, maxTop));
    this.scrollLeft = Math.max(0, this.scrollLeft);
  }
}